package com.example.expansetracker

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.exp

private lateinit var editTextDate: EditText
private lateinit var editTextAmount: EditText
private lateinit var spinner: Spinner
private lateinit var buttonAddExpense: Button

private lateinit var expenseDao: ExpenseDao


class AddExpense : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_expense, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        expenseDao = ExpenseDatabase.getDatabase(view.context).expenseDao()

        var selected_category = ""

        editTextDate = view.findViewById(R.id.editTextDate)
        editTextAmount = view.findViewById(R.id.editTextAmount)
        buttonAddExpense = view.findViewById(R.id.buttonAddExpense)

        spinner= view.findViewById(R.id.category)
        val categories = arrayOf("Food", "Entertainment", "Housing", "Utilities", "Fuel", "Automotive", "Misc")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Log.d("--------------", "onItemSelected: $position")
                selected_category = parent?.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        buttonAddExpense.setOnClickListener {
            val date = editTextDate.text.toString()
            val amount: Double = editTextAmount.text.toString().toDouble()
            Log.d("------------------", "onViewCreated: $date $amount $selected_category")
            if(date.isEmpty() || amount.equals(0.0) || selected_category.equals("")){
                Toast.makeText(view.context, "Please fill the complete Form", Toast.LENGTH_SHORT).show();
            }else{
                GlobalScope.launch(Dispatchers.IO) {
                    expenseDao.insertExpense(Expense(0L, date, amount, selected_category))
                }
            }
            }
        }
    }