package com.example.expansetracker

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ExpenseDao {

    @Query("SELECT * FROM expenses")
    fun getAllExpenses(): List<Expense>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
     fun insertExpense(expense: Expense)

     @Query("UPDATE expenses SET amount=:amount, date=:date, category=:category WHERE id=:expenseId")
     fun updateExpense(expenseId: Long, amount: Double, date: String, category: String)
}
