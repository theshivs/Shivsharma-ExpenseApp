package com.example.expansetracker

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

private const val DATE = "date"
private const val CATEGORY = "category"
private const val AMOUNT = "amount"
private const val ID = "id"

private lateinit var editTextDate: EditText
private lateinit var editTextAmount: EditText
private lateinit var spinner: Spinner
private lateinit var buttonUpdateExpense: Button

private var date: String? = null
private var category: String? = null
private var amount: Double? = null
private var expense_id: Long = 0L

private lateinit var expenseDao: ExpenseDao

class UpdateExpense : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            date = it.getString(DATE)
            amount = it.getDouble(AMOUNT)
            category = it.getString(CATEGORY)
            //FOOD
            expense_id = it.getLong(ID)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_update_expense, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        expenseDao = ExpenseDatabase.getDatabase(view.context).expenseDao()

        var selected_category = ""

        editTextDate = view.findViewById(R.id.editTextDate)
        editTextAmount = view.findViewById(R.id.editTextAmount)
        buttonUpdateExpense = view.findViewById(R.id.buttonUpdateExpense)

        spinner= view.findViewById(R.id.category)
        val categories = arrayOf("Food", "Entertainment", "Housing", "Utilities", "Fuel", "Automotive", "Misc")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        editTextDate.setText(date)
        editTextAmount.setText(amount.toString())
        spinner.setSelection(categories.indexOf(category))

        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Log.d("--------------", "onItemSelected: $position")
                selected_category = parent?.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        buttonUpdateExpense.setOnClickListener {
            val edit_date = editTextDate.text.toString()
            val edit_amount: Double = editTextAmount.text.toString().toDouble()
            Log.d("------------------", "onViewCreated: $date $amount $selected_category")
            if(edit_date.isEmpty() || edit_amount.equals(0.0) || selected_category.equals("")){
                Toast.makeText(view.context, "Please fill the complete Form", Toast.LENGTH_SHORT).show();
            }else{
                GlobalScope.launch(Dispatchers.IO) {
                    expenseDao.updateExpense(expense_id,edit_amount, edit_date, selected_category)
                }
            }
        }

    }

}