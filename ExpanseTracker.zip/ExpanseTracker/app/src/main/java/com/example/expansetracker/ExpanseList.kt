package com.example.expansetracker

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private lateinit var recyclerView: RecyclerView
private lateinit var add_expanse: Button
private lateinit var adapter: ExpenseAdapter

private lateinit var spinner: Spinner

private var expenseList: ArrayList<Expense> = ArrayList(emptyList())

class ExpanseList : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_expanse_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        add_expanse = view.findViewById(R.id.add_expanse)
        add_expanse.setOnClickListener {
            val fragementManager = parentFragmentManager
            val fragmentTransaction = fragementManager.beginTransaction()
            fragmentTransaction.replace(R.id.frame_layout, AddExpense())
                .addToBackStack(null)
            fragmentTransaction.commit()
        }

        recyclerView = view.findViewById(R.id.expanse_list)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = ExpenseAdapter(arrayListOf<Expense>())
        recyclerView.adapter = adapter

        initData()

        spinner= view.findViewById(R.id.category)
        val categories = arrayOf("","Food", "Entertainment", "Housing", "Utilities", "Fuel", "Automotive", "Misc")
        val spinner_adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories)
        spinner_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = spinner_adapter

        var selected_category = "Food"
        var filtered_expense = arrayListOf<Expense>()
        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Log.d("--------------", "onItemSelected: $position")
                selected_category = parent?.getItemAtPosition(position).toString()
                if(selected_category == ""){
                    adapter.updateData(expenseList)
                }else{
                    filtered_expense = ArrayList(expenseList.filter { e -> (
                            e.category == selected_category)
                    })
                    adapter.updateData(filtered_expense)
                }

            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    fun initData(){
        expenseList = arrayListOf<Expense>()
//        expenseList.add(Expense(0L, "30-01-2020", 10.2,"Personal"))
//        expenseList.add(Expense(0L, "30-01-2020", 10.2,"Personal"))
//        expenseList.add(Expense(0L, "30-01-2020", 10.2,"Personal"))
//        expenseList.add(Expense(0L, "30-01-2020", 10.2,"Personal"))
//        expenseList.add(Expense(0L, "30-01-2020", 10.2,"Personal"))

        GlobalScope.launch (Dispatchers.IO){
            val expanses = ExpenseDatabase.getDatabase(requireContext()).expenseDao().getAllExpenses()
            withContext(Dispatchers.Main){
                adapter.updateData(ArrayList(expanses))
                expenseList = ArrayList(expanses)
            }
        }

    }

    private fun replaceFragment(expenseList: Fragment){

    }

}