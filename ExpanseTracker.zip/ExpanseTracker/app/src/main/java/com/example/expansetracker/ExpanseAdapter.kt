package com.example.expansetracker

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView

class ExpenseAdapter(private var expenses: List<Expense>) :
    RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ExpenseAdapter.ExpenseViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.expanse_list_item, parent, false)
        return ExpenseViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ExpenseAdapter.ExpenseViewHolder, position: Int) {
        val currentExpense = expenses[position]
        holder.textDate.text = currentExpense.date
        holder.textAmount.text = currentExpense.amount.toString()
        holder.textCategory.text = currentExpense.category

        holder.itemView.setOnClickListener(object :View.OnClickListener{
            override fun onClick(v: View?) {
                val activity = v!!.context as AppCompatActivity
                Toast.makeText(activity, "${currentExpense.category}",Toast.LENGTH_SHORT).show()

                val bundle = Bundle()
                bundle.putLong("id", currentExpense.id)
                bundle.putString("category", currentExpense.category)
                bundle.putDouble("amount", currentExpense.amount)
                bundle.putString("date", currentExpense.date)

                val updateExpense = UpdateExpense()

                updateExpense.arguments = bundle

                activity.supportFragmentManager.beginTransaction()
                    .replace(R.id.frame_layout, updateExpense)
                    .addToBackStack(null)
                    .commit()
            }
        })
    }

    override fun getItemCount(): Int {
        return expenses.size
    }

    class ExpenseViewHolder (itemView: View):RecyclerView.ViewHolder(itemView) {
        val textDate: TextView = itemView.findViewById(R.id.date)
        val textAmount: TextView = itemView.findViewById(R.id.amount)
        val textCategory: TextView = itemView.findViewById(R.id.category)
    }

    fun updateData(newDataList: ArrayList<Expense>) {
        expenses = newDataList

        notifyDataSetChanged() // Notify adapter that data set has changed
    }
}